<div class="content">
	 
        <ul class="exo-menu">
            <li><a class="active" href="#"><i class="fa"></i> Home</a></li>
    
            <li class="mega-drop-down"><a href="#"><i class="fa"></i>Clothing</a>
                <div class="animated fadeIn mega-menu">
                    <div class="mega-menu-wrap">
                        <div class="row">
                            <div class="col-md-6">
                                <h4 class="row mega-title">SHOP BY PRODUCT</h4>
                                <div class="col-md-6">
                                    <div class="border-col">
                                        <nav role="navigation"><!--CKA-03/02/19-dd/mm/yy-->
                                            <ul class="stander">
                                                <li><a href="clothingPage" class="categoryClothing">T-shirts</a></li>
    
                                                <li><a href="#" class="categoryClothing">Jeans</a></li>
                                                <li><a href="#" class="categoryClothing">Shoes</a></li>
                                                <li><a href="#"></a></li>
                                                <li><a href="#"></a></li>
                                                <li><a href="#"></a></li>
                                            </ul>
                                        <nav><!--CKA-03/02/19-dd/mm/yy-->
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <ul class="stander">
                                        <li><a href="#"></a></li>
                                        <li><a href="#"></a></li>
                                        <li><a href="#"></a></li>
                                        <li><a href="#"></a></li>
                                        <li><a href="#"></a></li>
                                        <li><a href="#"></a></li>
                                    </ul>
                                </div>
                                    
                            </div>
                            <div class="col-md-6">
                                <h4 class="row mega-title">TRENDING</h4>
                                <div class="col-md-6">	
                                    <img class="img-responsive" src="uploads/AB09.png">		
                                </div>
                                <div class="col-md-6">
                                    <img class="img-responsive" src="uploads/AB10.png">	
                                </div>	
                            </div>
                        </div>
                    </div>	
                </div>
            </li>
    
            <li class="mega-drop-down"><a href="#"><i class="fa"></i>WORKOUT</a>
                <div class="animated fadeIn mega-menu">
                    <div class="mega-menu-wrap">
                        <div class="row">
                            <div class="col-md-6">
                                <h4 class="row mega-title">MEALS</h4>
                                <div class="col-md-6">
                                    <div class="border-col">
                                        <ul class="stander">
                                            <li><a href="#">Pre-workout Meals</a></li>
                                            <li><a href="#">post-workout Meals</a></li>
                                            <li><a href="#">Keep fit Meal</a></li>
                                            <li><a href="#">Everyday Meal Schedule</a></li>
                                            <li><a href="#"></a></li>
                                            <li><a href="#"></a></li>
                                        </ul>	
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <img class="img-responsive" src="uploads/ABdiet.jpg">	
                                </div>
                                    
                            </div>
                            <div class="col-md-6">
                                <h4 class="row mega-title">WORKOUT EXERCISES</h4>
                                <div class="col-md-6">
                                    <div class="border-col">
                                        <ul class="stander">
                                            <li><a href="#">Morning Exercises</a></li>
                                            <li><a href="#">Daily Routine</a></li>
                                            <li><a href="#">Keep fit Exercises</a></li>
                                            <li><a href="#"></a></li>
                                            <li><a href="#"></a></li>
                                            <li><a href="#"></a></li>
                                        </ul>	
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    
                                    <video id="videoWorkout" class="img-responsive" width="400" controls style="right: 100% ">
                                      <source src="uploads/ABworkout.mp4" type="video/mp4">
                                    </video>	
                                    
                            </div>
                        </div>
                    </div>	
                </div>
            </li>
    <!--  https://shielded-cove-24295.herokuapp.com/ -->
    <!-- 		<li class="drop-down"><a href="#"><i class="fa fa-cogs"></i> Flyout</a>
                
                <ul class="drop-down-ul animated fadeIn">
                <li class="flyout-right"><a href="#">Flyout Right</a>
                    <ul class="animated fadeIn">
                        <li><a href="#">Mobile</a></li>
                        <li><a href="#">Computer</a></li>
                        <li><a href="#">Watch</a></li>
                    </ul>
                </li>
                
                <li class="flyout-left"><a href="#">Flyout Left</a>
                    <ul class="animated fadeIn">
                        <li><a href="#">Mobile</a></li>
                        <li><a href="#">Computer</a></li>
                        <li><a href="#">Watch</a></li>
                    </ul>			
                </li>
                
                <li><a href="#">No Flyout</a></li>
                 
                </ul>
                
                
            </li> -->
    <!-- 		<li><a href="#"><i class="fa fa-cogs"></i> Services</a></li>
            <li><a href="#"><i class="fa fa-briefcase"></i> Portfolio</a></li>
            <li class="mega-drop-down"><a href="#"><i class="fa fa-list"></i> Mega Menu</a>
                <div class="animated fadeIn mega-menu">
                    <div class="mega-menu-wrap">
                        <div class="row">
                        <div class="col-md-4">
                            <h4 class="row mega-title">Feature</h4>
                                <img class="img-responsive" src="https://3.bp.blogspot.com/-rUk36pd-LbM/VcLb48X4f-I/AAAAAAAAGCI/Y_UxBAgEqwA/s1600/Magento_themes.jpg">
                            </div>
                            <div class="col-md-2">
                                    <h4 class="row mega-title">Standers</h4>
                                <ul class="stander">
                                    <li><a href="#">Mobile</a></li>
                                    <li><a href="#">Computer</a></li>
                                    <li><a href="#">Watch</a></li>
                                    <li><a href="#">laptop</a></li>
                                    <li><a href="#">Camera</a></li>
                                    <li><a href="#">I pad</a></li>
                                    <li><a class="view-more btn- btn-sm" href="#">View more</a></li>
                                </ul>
                            </div>
                            <div class="col-md-3">
                                <h4 class="row mega-title">Description</h4>
                                <ul class="description">
                                    <li><a href="#">Women</a>
                                        <span>Description of Women</span>
                                    </li>
                                    <li><a href="#">Men</a>
                                            <span>Description of men Cloths</span>
                                    </li>
                                    <li><a href="#">Kids</a>
                                            <span>Description of Kids Cloths</span>
                                    </li>
                                    <li><a href="#">Others</a>
                                            <span>Description of Others Cloths</span>
                                    </li>
                                    <li>
                                    <a class="view-more btn btn-sm " href="#">View more</a>
                                             
                                    </li>
                                </ul>
                            </div>
                            <div class="col-md-3">
                            <h4 class="row mega-title">Icon + Description</h4>
                                <ul class="icon-des">
                                    <li><a href="#"><i class="fa fa-globe"></i>Web</a></li>
                                    <li><a href="#"><i class="fa fa-mobile"></i>Mobile</a></li>
                                    <li><a href="#"><i class="fa fa-arrows-h"></i>Responsive</a></li>
                                    <li><a href="#"><i class="fa fa-desktop"></i>Desktop</a></li>
                                    <li><a href="#"><i class="fa fa-paint-brush"></i>UI/UX</a></li>
                                </ul>
                            </div>
                            
                        </div>
                    </div>	
                </div>
            </li> -->
    <!-- 		<li class="blog-drop-down"><a href="#"><i class="fa fa-bullhorn"></i> Blog</a>
                <div class="Blog animated fadeIn">
                    <div class="col-md-4">
                        <img class="img-responsive" src="https://2.bp.blogspot.com/-VG_e0pKfrDo/VcLb6JwZqfI/AAAAAAAAGCk/8ZgA9kZqTQ8/s1600/images3.jpg">
                        <div class="blog-des">
                    <h4 class="blog-title">Lorem ipsum dolor sit amet</h4>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod 
                            tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis
                            nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. 
                            Duis autem vel eum iriure dolor in hendrerit in vulputate. </p>
                            <a class="view-more btn- btn-sm" href="#">Read More</a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <img class="img-responsive" src="https://3.bp.blogspot.com/-hUt5FrdZHio/VcLb5dlwTBI/AAAAAAAAGCU/UUH5N1JkoQc/s1600/images1.jpg">
                        <div class="blog-des">
                        <h4 class="blog-title">Lorem ipsum dolor sit amet</h4>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod 
                            tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis
                            nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. 
                            Duis autem vel eum iriure dolor in hendrerit in vulputate. </p>
                                    <a class="view-more btn- btn-sm" href="#">Read More</a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <img class="img-responsive" src="https://4.bp.blogspot.com/-A7U1uPlSq6Y/VcLb5kKHCkI/AAAAAAAAGCc/7WghyndTEuY/s1600/images2.jpg">
                        <div class="blog-des">
                        <h4 class="blog-title">Lorem ipsum dolor sit amet</h4>
                            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod 
                            tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis
                            nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. 
                            Duis autem vel eum iriure dolor in hendrerit in vulputate. </p>
                                    <a class="view-more btn- btn-sm" href="#">Read More</a>
                        </div>
                    </div>
                     
                    
                </div>
            </li> -->
        <!-- 	<li  class="images-drop-down"><a  href="#"><i class="fa fa-photo"></i> Images</a>
                <div class="Images animated fadeIn">
                    <div class="col-md-3">
                        <h4>Images Title </h4>
                        <img class="img-responsive" src="https://2.bp.blogspot.com/-VG_e0pKfrDo/VcLb6JwZqfI/AAAAAAAAGCk/8ZgA9kZqTQ8/s1600/images3.jpg">
                    </div>
                    <div class="col-md-3">
                    <h4>Images Title </h4>
                        <img class="img-responsive" src="https://3.bp.blogspot.com/-hUt5FrdZHio/VcLb5dlwTBI/AAAAAAAAGCU/UUH5N1JkoQc/s1600/images1.jpg">
                    </div>
                    <div class="col-md-3">
                    <h4>Images Title </h4>
                        <img class="img-responsive" src="https://4.bp.blogspot.com/-A7U1uPlSq6Y/VcLb5kKHCkI/AAAAAAAAGCc/7WghyndTEuY/s1600/images2.jpg">
                    </div>
                    <div class="col-md-3">
                    <h4>Images Title </h4>
                        <img class="img-responsive"  src="https://3.bp.blogspot.com/-hGrnZIjzL2k/VcLb47kyQKI/AAAAAAAAGCQ/J6Q2IAHIQvQ/s1600/image4.jpg">
                    </div>
                    
                </div>
            
            </li> -->
            <li><a href="#"><i class="fa"></i> Contact</a>
                <div class="contact">
            
                </div>
            </li>
            <li><a href="#"><i class="fa"></i> WOMEN</a>
            </li>
            <li>
            <!-- <a  href="#"> CKA-06/02/19-dd/mm/yy-removed <li> and class -->
                <!-- <form method='post' action='/logout'> -->
                    <!-- <i ><button class="btn btn-primary" >Logout</button></i> CKA-06/02/19-dd/mm/yy-Added style -->
                <!-- </form>	 -->
                
             <!-- </a> -->
            </li>
            <a href="#" class="toggle-menu visible-xs-block">|||</a>		
        </ul>
    
    </div>
    